@extends("master")

@section("content")
<br>
    <br>
        <br>
            <h2>Selamat Datang di E-Akademik Universitas Singaperbangsa Karawang</h2>
            <div class="position-absolute top-50 start-50 translate-middle">   
            <a class="btn btn-dark" href="/dosen" role="button">DOSEN</a>
            <a class="btn btn-dark" href="/mahasiswa" role="button">MAHASISWA</a>
            <a class="btn btn-dark" href="/matakuliah" role="button">MATAKULIAH</a>
            </div>
@endsection